package entities;

public enum PowerUpType {
    EXPAND_PADDLE,
    MULTIBALL,
    FIREBALL
}
