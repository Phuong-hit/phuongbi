package entities;

import java.awt.*;

public class Brick {
    public int x, y, width, height;
    public boolean destroyed = false;
    private Color color;

    public Brick(int x, int y, int width, int height, Color color) {
        this.x = x; this.y = y;
        this.width = width; this.height = height;
        this.color = color;
    }

    public void draw(Graphics g) {
        if (!destroyed) {
            g.setColor(color);
            g.fillRect(x, y, width, height);
            g.setColor(Color.BLACK);
            g.drawRect(x, y, width, height);
        }
    }

    public Rectangle getRect() {
        return new Rectangle(x, y, width, height);
    }
}
