package entities;

import java.awt.*;
import java.awt.geom.Rectangle2D;

public class Brick {
    public int x, y, width, height;
    private Color color;
    private BrickType type;
    private int hitPoints;
    public boolean destroyed = false;

    public Brick(int x, int y, int width, int height, Color color, BrickType type) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.color = color;
        this.type = type;
        this.hitPoints = type.getHitPoints();
    }

    public Rectangle getRect() {
        return new Rectangle(x, y, width, height);
    }

    public boolean hit() {
        if (type == BrickType.UNBREAKABLE) return false;
        hitPoints--;
        if (hitPoints <= 0) {
            destroyed = true;
            return true; // báo là gạch bị phá
        }
        return false;
    }

    public void draw(Graphics g) {
        if (destroyed) return;

        switch (type) {
            case WEAK -> g.setColor(new Color(255, 180, 180));
            case STRONG -> g.setColor(new Color(120, 120, 255));
            case UNBREAKABLE -> g.setColor(new Color(80, 80, 80));
            default -> g.setColor(color);
        }

        g.fillRect(x, y, width, height);
        g.setColor(Color.BLACK);
        g.drawRect(x, y, width, height);

        if (type == BrickType.STRONG) {
            g.setColor(Color.WHITE);
            g.setFont(new Font("Arial", Font.BOLD, 12));
            g.drawString(String.valueOf(hitPoints), x + width / 2 - 4, y + height / 2 + 5);
        }
    }

    public BrickType getType() { return type; }
    public boolean isDestroyed() { return destroyed; }
    public int getCenterX() { return x + width / 2; }
    public int getCenterY() { return y + height / 2; }
}
