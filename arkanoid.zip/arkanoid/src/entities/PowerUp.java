package entities;

import java.awt.*;
import java.awt.geom.Rectangle2D;

public class PowerUp {
    public static final int SIZE = 20;
    private PowerUpType type;
    private double x, y;
    private double speedY = 2.5;
    private boolean active = true;

    public PowerUp(PowerUpType type, double x, double y) {
        this.type = type;
        this.x = x - SIZE / 2.0;
        this.y = y;
    }

    public void update() {
        y += speedY;
    }

    public void draw(Graphics g) {
        if (!active) return;
        Color c = switch (type) {
            case EXPAND_PADDLE -> Color.CYAN;
            case MULTIBALL -> Color.MAGENTA;
            case FIREBALL -> Color.ORANGE;
        };
        g.setColor(c);
        g.fillOval((int) x, (int) y, SIZE, SIZE);
        g.setColor(Color.BLACK);
        g.drawOval((int) x, (int) y, SIZE, SIZE);
    }

    public Rectangle2D getRect() {
        return new Rectangle2D.Double(x, y, SIZE, SIZE);
    }

    public PowerUpType getType() { return type; }
    public boolean isActive() { return active; }
    public void deactivate() { active = false; }
    public double getY() { return y; }
}
