package entities;

import java.awt.*;

public class WeakBrick extends Brick {
    public WeakBrick(int x, int y, int w, int h) {
        super(x, y, w, h, 1, Color.CYAN);
    }
}
