package engine;

import entities.*;
import levels.Level;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class GamePanel extends JPanel implements KeyListener {
    private Paddle paddle;
    private Ball ball;
    private Level level;

    private boolean gameOver;
    private int score;

    private GameLoop loop;

    private static final int WIDTH = 800;
    private static final int HEIGHT = 600;

    public GamePanel() {
        setPreferredSize(new Dimension(WIDTH, HEIGHT));
        setBackground(Color.BLACK);
        setFocusable(true);
        addKeyListener(this);
        startGame();
    }

    public void startGame() {
        paddle = new Paddle(WIDTH / 2 - 50, HEIGHT - 50, 100, 10, Color.WHITE);
        ball = new Ball(WIDTH / 2, HEIGHT / 2, 20, Color.YELLOW);
        level = new Level(6, 8);
        score = 0;
        gameOver = false;

        loop = new GameLoop(this);
        new Thread(loop).start();
    }

    public void updateGame() {
        if (gameOver) return;

        ball.move();
        paddle.update();

        // Wall collisions
        if (ball.x <= 0 || ball.x + ball.size >= WIDTH) ball.dx = -ball.dx;
        if (ball.y <= 0) ball.dy = -ball.dy;

        // Bottom edge → lose
        if (ball.y + ball.size >= HEIGHT) {
            gameOver = true;
            loop.stop();
        }

        // Paddle collision
        if (ball.getRect().intersects(paddle.getRect())) {
            ball.dy = -Math.abs(ball.dy);
        }

        // Brick collisions
        for (Brick b : level.bricks) {
            if (!b.destroyed && ball.getRect().intersects(b.getRect())) {
                b.destroyed = true;
                ball.dy = -ball.dy;
                score += 10;
            }
        }
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        draw(g);
    }

    public void draw(Graphics g) {
        paddle.draw(g);
        ball.draw(g);
        level.draw(g);

        g.setColor(Color.WHITE);
        g.drawString("Score: " + score, 20, 20);
        g.drawString("Bricks left: " + level.getRemainingBricks(), 20, 40);

        if (gameOver) {
            g.setFont(new Font("Arial", Font.BOLD, 36));
            g.setColor(Color.RED);
            g.drawString("GAME OVER", WIDTH / 2 - 120, HEIGHT / 2);
            g.setFont(new Font("Arial", Font.PLAIN, 18));
            g.drawString("Press ENTER to restart", WIDTH / 2 - 110, HEIGHT / 2 + 40);
        }
    }

    @Override
    public void keyPressed(KeyEvent e) {
        int code = e.getKeyCode();
        if (code == KeyEvent.VK_LEFT) paddle.setLeft(true);
        if (code == KeyEvent.VK_RIGHT) paddle.setRight(true);

        if (code == KeyEvent.VK_ENTER && gameOver) startGame();
    }

    @Override
    public void keyReleased(KeyEvent e) {
        int code = e.getKeyCode();
        if (code == KeyEvent.VK_LEFT) paddle.setLeft(false);
        if (code == KeyEvent.VK_RIGHT) paddle.setRight(false);
    }

    @Override
    public void keyTyped(KeyEvent e) {}
}
