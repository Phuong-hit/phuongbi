package engine;

import entities.*;
import levels.Level;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

public class GamePanel extends JPanel implements KeyListener {
    private Paddle paddle;
    private Ball ball;
    private Level level;

    private ArrayList<PowerUp> powerUps = new ArrayList<>();
    private Random random = new Random();

    private boolean gameOver;
    private int score;

    private GameLoop loop;

    private static final int WIDTH = 800;
    private static final int HEIGHT = 600;

    public GamePanel() {
        setPreferredSize(new Dimension(WIDTH, HEIGHT));
        setBackground(Color.BLACK);
        setFocusable(true);
        addKeyListener(this);
        startGame();
    }

    public void startGame() {
        paddle = new Paddle(WIDTH / 2 - 50, HEIGHT - 50, 100, 10, Color.WHITE);
        ball = new Ball(WIDTH / 2, HEIGHT / 2, 20, Color.YELLOW);
        level = new Level(6, 8);
        score = 0;
        gameOver = false;
        powerUps.clear();

        loop = new GameLoop(this);
        new Thread(loop).start();
    }

    public void updateGame() {
        if (gameOver) return;

        ball.move();
        paddle.update();

        // Tường
        if (ball.x <= 0 || ball.x + ball.size >= WIDTH) ball.dx = -ball.dx;
        if (ball.y <= 0) ball.dy = -ball.dy;

        // Dưới
        if (ball.y + ball.size >= HEIGHT) {
            gameOver = true;
            loop.stop();
        }

        // Paddle
        if (ball.getRect().intersects(paddle.getRect())) {
            ball.dy = -Math.abs(ball.dy);
        }

        // Brick collisions
        for (Brick b : level.bricks) {
            if (!b.destroyed && ball.getRect().intersects(b.getRect())) {
                boolean destroyed = b.hit();
                ball.dy = -ball.dy;
                if (destroyed) {
                    score += 10;
                    maybeSpawnPowerUp(b.getCenterX(), b.getCenterY());
                }
            }
        }

        // Update PowerUps
        Iterator<PowerUp> it = powerUps.iterator();
        while (it.hasNext()) {
            PowerUp p = it.next();
            p.update();
            if (p.getY() > HEIGHT) {
                it.remove();
                continue;
            }
            if (p.getRect().intersects(paddle.getRect())) {
                applyPowerUp(p.getType());
                it.remove();
            }
        }
    }

    private void maybeSpawnPowerUp(int x, int y) {
        if (random.nextDouble() < 0.2) { // 20% spawn rate
            PowerUpType[] types = PowerUpType.values();
            PowerUpType type = types[random.nextInt(types.length)];
            powerUps.add(new PowerUp(type, x, y));
        }
    }

    private void applyPowerUp(PowerUpType type) {
        switch (type) {
            case EXPAND_PADDLE -> paddle.width += 50;
            case MULTIBALL -> { ball.dx *= 1.2; ball.dy *= 1.2; }
            case FIREBALL -> ball.color = Color.ORANGE;
        }
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        draw(g);
    }

    public void draw(Graphics g) {
        paddle.draw(g);
        ball.draw(g);
        level.draw(g);
        for (PowerUp p : powerUps) p.draw(g);

        g.setColor(Color.WHITE);
        g.drawString("Score: " + score, 20, 20);
        g.drawString("Bricks left: " + level.getRemainingBricks(), 20, 40);

        if (gameOver) {
            g.setFont(new Font("Arial", Font.BOLD, 36));
            g.setColor(Color.RED);
            g.drawString("GAME OVER", WIDTH / 2 - 120, HEIGHT / 2);
            g.setFont(new Font("Arial", Font.PLAIN, 18));
            g.drawString("Press ENTER to restart", WIDTH / 2 - 110, HEIGHT / 2 + 40);
        }
    }

    @Override
    public void keyPressed(KeyEvent e) {
        int code = e.getKeyCode();
        if (code == KeyEvent.VK_LEFT) paddle.setLeft(true);
        if (code == KeyEvent.VK_RIGHT) paddle.setRight(true);

        if (code == KeyEvent.VK_ENTER && gameOver) startGame();
    }

    @Override
    public void keyReleased(KeyEvent e) {
        int code = e.getKeyCode();
        if (code == KeyEvent.VK_LEFT) paddle.setLeft(false);
        if (code == KeyEvent.VK_RIGHT) paddle.setRight(false);
    }

    @Override
    public void keyTyped(KeyEvent e) {}
}
