package engine;

public class GameLoop implements Runnable {
    private GamePanel panel;
    private boolean running = true;

    public GameLoop(GamePanel panel) {
        this.panel = panel;
    }

    @Override
    public void run() {
        while (running) {
            panel.updateGame();
            panel.repaint();

            try {
                Thread.sleep(10);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public void stop() {
        running = false;
    }
}
