import ui.GameWindow;
import engine.GamePanel;

public class Main {
    public static void main(String[] args) {
        new GameWindow(new GamePanel());
    }
}
