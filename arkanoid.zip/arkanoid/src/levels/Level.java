package levels;

import entities.*;
import java.awt.*;
import java.util.ArrayList;

public class Level {
    public ArrayList<Brick> bricks = new ArrayList<>();

    public Level(int rows, int cols) {
        int brickWidth = 80;
        int brickHeight = 20;
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                int x = 50 + c * (brickWidth + 5);
                int y = 50 + r * (brickHeight + 5);

                if (r == 0 && c % 4 == 0) bricks.add(new UnbreakableBrick(x, y, brickWidth, brickHeight));
                else if (r % 2 == 0) bricks.add(new StrongBrick(x, y, brickWidth, brickHeight));
                else bricks.add(new WeakBrick(x, y, brickWidth, brickHeight));
            }
        }
    }

    public void draw(Graphics g) {
        for (Brick b : bricks) b.draw(g);
    }

    public int getRemainingBricks() {
        int count = 0;
        for (Brick b : bricks)
            if (!b.destroyed && !b.isUnbreakable()) count++;
        return count;
    }
}
