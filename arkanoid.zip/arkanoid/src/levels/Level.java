package levels;

import entities.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.Random;

public class Level {
    public ArrayList<Brick> bricks = new ArrayList<>();
    private static final Random RNG = new Random();

    public Level(int rows, int cols) {
        int brickWidth = 80;
        int brickHeight = 20;
        Color[] colors = {Color.RED, Color.ORANGE, Color.YELLOW, Color.GREEN, Color.CYAN, Color.MAGENTA};
        BrickType[] types = BrickType.values();

        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                int x = 50 + c * (brickWidth + 5);
                int y = 50 + r * (brickHeight + 5);
                BrickType randomType = types[RNG.nextInt(types.length)];
                bricks.add(new Brick(x, y, brickWidth, brickHeight, colors[r % colors.length], randomType));
            }
        }
    }

    public void draw(Graphics g) {
        for (Brick b : bricks) {
            b.draw(g);
        }
    }

    public int getRemainingBricks() {
        int count = 0;
        for (Brick b : bricks) if (!b.destroyed) count++;
        return count;
    }
}
