package levels;

import entities.Brick;
import java.awt.*;
import java.util.ArrayList;

public class Level {
    public ArrayList<Brick> bricks = new ArrayList<>();

    public Level(int rows, int cols) {
        int brickWidth = 80;
        int brickHeight = 20;
        Color[] colors = {Color.RED, Color.ORANGE, Color.YELLOW, Color.GREEN, Color.CYAN, Color.MAGENTA};

        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                int x = 50 + c * (brickWidth + 5);
                int y = 50 + r * (brickHeight + 5);
                bricks.add(new Brick(x, y, brickWidth, brickHeight, colors[r % colors.length]));
            }
        }
    }

    public void draw(Graphics g) {
        for (Brick b : bricks) {
            b.draw(g);
        }
    }

    public int getRemainingBricks() {
        int count = 0;
        for (Brick b : bricks) if (!b.destroyed) count++;
        return count;
    }
}
